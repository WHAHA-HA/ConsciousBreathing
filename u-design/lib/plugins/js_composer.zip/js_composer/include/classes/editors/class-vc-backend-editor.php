<?php
/**
 * WPBakery Visual Composer admin editor
 *
 * @package WPBakeryVisualComposer
 *
 */

/**
 * VC backend editor.
 *
 * This editor is available on default Wp post/page admin edit page. ON admin_init callback adds meta box to
 * edit page.
 *
 * @since 4.2
 */
class Vc_Backend_Editor {

	protected $layout;

	/**
	 * This method is called by Vc_Manager to register required action hooks for VC backend editor.
	 *
	 * @since  4.2
	 * @access public
	 */
	public function addHooksSettings() {
		add_action( 'edit_post', array( &$this, 'save' ) );
		add_action( 'wp_ajax_wpb_get_element_backend_html', array( &$this, 'elementBackendHtml' ) );
		// load backend editor
		if ( function_exists( 'add_theme_support' ) ) {
			add_theme_support( 'post-thumbnails' );
		}
		add_post_type_support( 'page', 'excerpt' );
		add_action( 'admin_init', array( &$this, 'render' ), 5 );
		add_action( 'admin_print_scripts-post.php', array( &$this, 'printScriptsMessages' ) );
		add_action( 'admin_print_scripts-post-new.php', array( &$this, 'printScriptsMessages' ) );
		// Load required vendors classes;
		visual_composer()->vendorsManager()->load();
	}

	/**
	 *	Calls add_meta_box to create Editor block. Block is rendered by WPBakeryVisualComposerLayout.
	 *
	 * @see WPBakeryVisualComposerLayout
	 * @since  4.2
	 * @access public
	 */
	public function render() {
		$post_types = vc_editor_post_types();
		foreach ( $post_types as $type ) {
			add_meta_box( 'wpb_visual_composer', __( 'Visual Composer', "js_composer" ), Array( $this->getLayout(), 'output' ), $type, 'normal', 'high' );
		}
	}

	/**
	 * Getter for WPBakeryVisualComposerLayout.
	 *
	 * @see WPBakeryVisualComposerLayout
	 * @since  4.2
	 * @access public
	 * @return WPBakeryVisualComposerLayout
	 */
	public function getLayout() {
		require_once vc_path_dir( 'TEMPLATES_DIR', 'backend_editor/layouts.php' );
		if ( $this->layout === null )
			$this->layout = new WPBakeryVisualComposerLayout();
		return $this->layout;
	}

	/**
	 * Enqueue required javascript libraries and css files.
	 *
	 * This method also setups reminder about license activation.
	 *
	 * @since  4.2
	 * @access public
	 */
	public function printScriptsMessages() {
		if ( in_array( get_post_type(), vc_editor_post_types() )) {
			vc_license()->setupReminder();
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_style( 'farbtastic' );
			wp_enqueue_style( 'ui-custom-theme' );
			wp_enqueue_style( 'isotope-css' );
			wp_enqueue_style( 'animate-css' );
			wp_enqueue_style( 'js_composer' );
			wp_enqueue_style( 'wpb_jscomposer_autosuggest' );

			WPBakeryShortCode_Settings::enqueueCss();

			wp_enqueue_script( 'jquery-ui-tabs' );
			wp_enqueue_script( 'jquery-ui-sortable' );
			wp_enqueue_script( 'jquery-ui-droppable' );
			wp_enqueue_script( 'jquery-ui-draggable' );
			wp_enqueue_script( 'jquery-ui-accordion' );
			wp_enqueue_script( 'jquery-ui-autocomplete' );

			wp_enqueue_script( 'farbtastic' );

			//MMM wp_enqueue_script('bootstrap-js');
			wp_enqueue_script( 'isotope' );
			wp_enqueue_script( 'wpb_bootstrap_modals_js' );
			wp_enqueue_script( 'wpb_scrollTo_js' );
			wp_enqueue_script( 'wpb_php_js' );
			// js composer js app {{
			// wpb_js_composer_js_sortable
			wp_enqueue_script( 'wpb_js_composer_js_sortable' );
			wp_enqueue_script( 'wpb_json-js' );


			wp_enqueue_script( 'wpb_js_composer_js_tools' );
			wp_enqueue_script( 'wpb_js_composer_js_storage' );
			wp_enqueue_script( 'wpb_js_composer_js_models' );
			wp_enqueue_script( 'wpb_js_composer_js_view' );
			wp_enqueue_script( 'wpb_js_composer_js_custom_views' );

			wp_enqueue_script( 'wpb_js_composer_js_backbone' );
			wp_enqueue_script( 'wpb_jscomposer_composer_js' );
			wp_enqueue_script( 'wpb_jscomposer_shortcode_js' );
			wp_enqueue_script( 'wpb_jscomposer_modal_js' );
			wp_enqueue_script( 'wpb_jscomposer_templates_js' );
			wp_enqueue_script( 'wpb_jscomposer_stage_js' );
			wp_enqueue_script( 'wpb_jscomposer_layout_js' );
			wp_enqueue_script( 'wpb_jscomposer_row_js' );
			wp_enqueue_script( 'wpb_jscomposer_settings_js' );
			wp_enqueue_script( 'wpb_jscomposer_media_editor_js' );
			wp_enqueue_script( 'wpb_jscomposer_autosuggest_js' );
			// }}
			wp_enqueue_script( 'wpb_js_composer_js' );
			WPBakeryShortCode_Settings::enqueueJs();
		}
	}

	/**
	 * Save generated shortcodes, html and visual composer status in posts meta.
	 *
	 * @since  3.0
	 * @access public
	 * @param $post_id - current post id
	 * @return void
	 */
	public function save( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		$value = vc_post_param( 'wpb_vc_js_status' );
		if ( $value !== null ) {
			// Add value
			if ( get_post_meta( $post_id, '_wpb_vc_js_status' ) == '' ) {
				add_post_meta( $post_id, '_wpb_vc_js_status', $value, true );
			} // Update value
			elseif ( $value != get_post_meta( $post_id, '_wpb_vc_js_status', true ) ) {
				update_post_meta( $post_id, '_wpb_vc_js_status', $value );
			}
			// Delete value
			elseif ( $value == '' ) {
				delete_post_meta( $post_id, '_wpb_vc_js_status', get_post_meta( $post_id, '_wpb_vc_js_status', true ) );
			}
		}

		if ( ( $value = vc_post_param( 'wpb_vc_js_interface_version' ) ) !== null ) {
			update_post_meta( $post_id, '_wpb_vc_js_interface_version', $value );
		}
	}

	/**
	 * Create shortcode's string.
	 *
	 * @since  3.0
	 * @access public
	 * @deprecated
	 */
	public function elementBackendHtml() {
		global $current_user;
		get_currentuserinfo();
		$data_element = vc_post_param( 'data_element' );

		/** @xvar $settings - get use group access rules */
		$settings = WPBakeryVisualComposerSettings::get( 'groups_access_rules' );
		$role = $current_user->roles[0];

		if ( $data_element == 'vc_column' && vc_post_param( 'data_width' ) !== null ) {
			$output = do_shortcode( '[vc_column width="' . vc_post_param( 'data_width' ) . '"]' );
			echo $output;
		} elseif ( $data_element == 'vc_row' || $data_element == 'vc_row_inner' ) {
			$output = do_shortcode( '[' . $data_element . ']' );
			echo $output;
		} elseif ( ! isset( $settings[$role]['shortcodes'] ) || ( isset( $settings[$role]['shortcodes'][$data_element] ) && (int)$settings[$role]['shortcodes'][$data_element] == 1 ) ) {
			$output = do_shortcode( '[' . $data_element . ']' );
			echo $output;
		}
		die();
	}
}
