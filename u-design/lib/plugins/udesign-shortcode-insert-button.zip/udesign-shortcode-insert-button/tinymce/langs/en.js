tinyMCE.addI18n({en:{
udesignShortcodeInsert:{	
desc : 'Insert a U-Design Shortcode'
}}});
